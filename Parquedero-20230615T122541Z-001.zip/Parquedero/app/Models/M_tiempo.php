<?php

namespace App\Models;

use CodeIgniter\Model;

class M_tiempo extends Model
{
    protected $table = 'registro_tiempo';
    protected $primaryKey = 'idTiempo';
    protected $allowedFields = ['idConductor', 'idVehiculo', 'fecha_hora_ingreso', 'fecha_hora_salida', 'valor_pagar'];
}
