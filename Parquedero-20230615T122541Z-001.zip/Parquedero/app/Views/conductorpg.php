<!DOCTYPE html>
<html lang="en">

<head>
	<title>Conductor</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body >
<style>
   body {
      font-family: 'Times New Roman', Times, serif;
      background-color: #e6e6e6;
      margin: 0;
      padding: 0;
   }

   h1 {
      color: #800000;
      text-align: center;
      margin-top: 30px;
   }

   ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      margin-top: 30px;
      border-top: 2px solid #800000;
      border-bottom: 2px solid #800000;
      padding: 10px 0;
   }

   li {
      margin-right: 20px;
   }

   a {
      text-decoration: none;
      color: #800000;
      font-weight: bold;
      transition: color 0.3s ease;
   }

   a:hover {
      color: #ff0000;
   }
</style>


		<h1>Registro Conductor</h1>
            <ul>
                <li><a href="<?php echo base_url('welcome_message'); ?>">Volver!</a></li>
			</ul>


	<div class="container"><br> <br>
		<div class="container-fluid">
			<div>
				<a href="<?php echo base_url('agregar'); ?>"> <button type="button" class="btn btn-primary">agregar</button></a>


			</div><br>
			<table class="table table-dark table-striped">
				<thead>
					<tr>
						<th scope="col">ID</th>
						<th scope="col">cedula</th>
						<th scope="col">nombre</th>
						<th scope="col">direccion</th>
						<th scope="col">telefono</th>
					</tr>
				</thead>

				<tbody>
					<?php foreach ($conductores as $pac) :
						# code...
					?>
						<tr>
							<th scope="row"> <?= $pac['idConductor'] ?></th>
							<td><?= $pac['cedula'] ?></td>
							<td><?= $pac['nombre'] ?></td>
							<td><?= $pac['direccion'] ?></td>
							<td><?= $pac['telefono'] ?></td>
							<td><a href="<?php echo base_url('editar/' . $pac['idConductor']) ?>"><button type="button" class="btn btn-primary">Edit</button></a> <a href="<?php echo base_url('eliminar/' . $pac['idConductor']) ?>"><button type="button" class="btn btn-danger">Borrar</button></a></td>
						</tr>
					<?php endforeach;

					?>
				</tbody>

			</table>

		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</body>

</html>