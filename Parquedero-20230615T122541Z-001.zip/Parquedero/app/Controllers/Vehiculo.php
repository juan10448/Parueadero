<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\m_vehiculo;
class Vehiculo extends Controller{
    
    public function index()
    {
        $pac = new m_vehiculo();
        $datos['vehiculos']=$pac->findAll();
        return view('vehiculopg',$datos);
    }


    public function agregarV()
    {
        return view('agregarV');
    }

    public function insertarV()
    {
        $pac = new m_vehiculo();

        $data=[
            'placa' => $_POST['placa'],
            'marca' => $_POST['marca'],
            'modelo' => $_POST['modelo'],
            'color' => $_POST['color'],
        ];

        $pac->insert($data);
        return redirect()->to(base_url('vehiculopg'));

    }

    public function eliminarV($idVehiculo=null)
    {
        $pac = new m_vehiculo();
        $pac->delete($idVehiculo);

        return redirect()->to(base_url('vehiculopg'));
    }

    public function editarV($idVehiculo = null)
    {
        $pac = new m_vehiculo();
        $registro['vehiculos']= $pac->find($idVehiculo);

      return view('actualizandoV',$registro);

      return redirect()->to(base_url('vehiculopg'));
    }

    public function factualizarV()
    {
        $pac = new m_vehiculo();
        $idVehiculo= $_POST['idVehiculo'];

        $data = [
            'placa' => $_POST['placa'],
            'marca' => $_POST['marca'],
            'modelo' => $_POST['modelo'],
            'color' => $_POST['color'],
        ];
        $pac->update($idVehiculo,$data);
        return redirect()->to(base_url('vehiculopg'));
    }
}