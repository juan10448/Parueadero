<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\m_conductor;
class Conductor extends Controller{
    
    public function index()
    {
        $pac = new m_conductor();
        $datos['conductores']=$pac->findAll();
        return view('conductorpg',$datos);
    }


    public function agregar()
    {
        return view('agregar');
    }

    public function insertar()
    {
        $pac = new m_conductor();

        $data=[
            'cedula' => $_POST['cedula'],
            'nombre' => $_POST['nombre'],
            'direccion' => $_POST['direccion'],
            'telefono' => $_POST['telefono'],
        ];

        $pac->insert($data);
        return redirect()->to(base_url('conductorpg'));

    }


    public function eliminar($idConductor=null)
    {
        $pac = new m_conductor();
        $pac->delete($idConductor);

        return redirect()->to(base_url('conductorpg'));
    }

    public function editar($idConductor = null)
    {
        $pac = new m_conductor();
        $registro['conductores']= $pac->find($idConductor);

      return view('actualizando',$registro);

      return redirect()->to(base_url('conductorpg'));
    }

    public function factualizar()
    {
        $pac = new m_conductor();
        $idConductor= $_POST['idConductor'];

        $data = [
            'cedula' => $_POST['cedula'],
            'nombre' => $_POST['nombre'],
            'direccion' => $_POST['direccion'],
            'telefono' => $_POST['telefono'],
        ];
        $pac->update($idConductor,$data);
        return redirect()->to(base_url('conductorpg'));
    }
}